
<?php $__env->startSection('content'); ?>


<div class="w-4/5 m-auto ">
    <div class="py-15 text-center">
        <h1 class="text-5xl font-hairline">
           More Info
        </h1>
    </div>

    <div class="py-15 px-5 border border-gray-300 rounded-3xl">
        <label for="email" class="block  text-gray-700 text-sm font-bold mb-2 sm:mb-4">
            <?php echo e(__('E-Mail Address')); ?>:
        </label>

        <input id="email" type="email"
                            class="form-input w-1/6 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                            value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Internship\laravelblog\resources\views/info.blade.php ENDPATH**/ ?>