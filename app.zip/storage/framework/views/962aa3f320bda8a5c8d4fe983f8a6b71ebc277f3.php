
<?php $__env->startSection('content'); ?>
    
    <div class="w-4/5 m-auto text-left">
        <div class="py-15">
            <h1 class="text-6xl">
                Update Post
            </h1>
        </div>
    </div>

    <?php if($errors->any()): ?>
        <div class="w-4/5 m-auto">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="w-full mb-4 text-gray-50 bg-red-700 rounded-2xl py-4 px-8">
                        <?php echo e($error); ?>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="w-4/5 m-auto pt-20">
        <form action="/wblog/<?php echo e($wpost->slug); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <input type="text" name="etitle" value="<?php echo e($wpost->etitle); ?>" class="bg-transparent block border-b-2 w-full h-20 text-3xl outline-none">
            <input type="text" name="stitle" value="<?php echo e($wpost->stitle); ?>" class="bg-transparent block border-b-2 w-full h-20 text-3xl outline-none">
        
            <textarea name="ehighlight"  class="py-15 bg-transparent block border-b-2 w-full h-25 text-l outline-none"><?php echo e($wpost->ehighlight); ?></textarea>
            <textarea name="shighlight"  class="py-15 bg-transparent block border-b-2 w-full h-25 text-l outline-none"><?php echo e($wpost->shighlight); ?></textarea>
            
            <textarea name="edescription" class="py-20 bg-transparent block border-b-2 w-full h-60 text-l outline-none"><?php echo e($wpost->edescription); ?></textarea>
            <textarea name="sdescription" class="py-20 bg-transparent block border-b-2 w-full h-60 text-l outline-none"><?php echo e($wpost->sdescription); ?></textarea>

            <input type="text" name="week"  value="<?php echo e($wpost->week); ?>"  class="pt-10 bg-transparent block border-b-2 h-18 text-s outline-none"><br>

            <button type="submit" class="uppercase mt-15 bg-blue-500 text-gray-100 text-sm font-extrabold py-4 px-8 rounded-3xl">
                Submit Post
            </button>
        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Internship\laravelblog\resources\views/wblog/edit.blade.php ENDPATH**/ ?>