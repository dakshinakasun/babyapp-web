
<?php $__env->startSection('content'); ?>
    
    <div class="w-4/5 m-auto text-left">
        <div class="py-15">
            <h1 class="text-6xl">
                Create Post
            </h1>
        </div>
    </div>

    <?php if($errors->any()): ?>
        <div class="w-4/5 m-auto">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="w-full mb-4 text-gray-50 bg-red-700 rounded-2xl py-4 px-8">
                        <?php echo e($error); ?>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="w-4/5 m-auto pt-20">
        <form action="/mblog" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <input type="text" name="etitle" placeholder="Title..." class="bg-transparent block border-b-2 w-full h-18 text-3xl outline-none">
            <input type="text" name="stitle" placeholder="ශීර්ෂය..." class="bg-transparent block border-b-2 w-full h-18 text-3xl outline-none">

            <textarea name="ehighlight" placeholder="Highlight Description..." class="py-15 bg-transparent block border-b-2 w-full h-25 text-l outline-none"></textarea>
            <textarea name="shighlight" placeholder="විස්තරය ඉස්මතු කරන්න..." class="py-15 bg-transparent block border-b-2 w-full h-25 text-l outline-none"></textarea>
        
            <textarea id="des1" name="edescription" placeholder="Description..." class="py-20 bg-transparent block border-b-2 w-full h-100 text-l outline-none"></textarea>
            <textarea id="des2" name="sdescription" placeholder="විස්තර..." class="py-20 bg-transparent block border-b-2 w-full h-100 text-l outline-none"></textarea>

            <div class="bg-gray-lighter pt-15">
                <label class="w-44 flex flex-col items-center px-2 py-3 bg-white-rounded-sm shadow-lg tracking-wide uppercase border border-blue cursor-pointer">
                    <span class="mt-2 text-base leading-none">
                        Select a file
                    </span>
                    <input type="file" name="image" class="hidden">
                </label>
            </div>

            <input type="text" name="month"  placeholder="Month - No.##"  class="pt-10 bg-transparent block border-b-2 h-18 text-s outline-none"><br>

            <button type="submit" class="uppercase mt-15 bg-blue-500 text-gray-50 text-sm font-extrabold py-4 px-8 rounded-3xl">
                Submit Post
            </button>
        </form>
    </div>
    
    <script src="https://cdn.tiny.cloud/1/7984dx8arenaj5gc4hg58tf6n3p5lxfx4sfi6601ikg47og8/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>

    <script>
        tinymce.init({
          selector: 'textarea#des1,#des2',
          plugins: 'a11ychecker advcode casechange export formatpainter linkchecker autolink lists checklist media mediaembed pageembed permanentpen powerpaste table advtable tinycomments tinymcespellchecker',
          toolbar: 'a11ycheck addcomment showcomments casechange checklist code export formatpainter pageembed permanentpen table',
          toolbar_mode: 'floating',
          tinycomments_mode: 'embedded',
          tinycomments_author: 'Author name',
       });
      </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Internship\backup\resources\views/mblog/create.blade.php ENDPATH**/ ?>