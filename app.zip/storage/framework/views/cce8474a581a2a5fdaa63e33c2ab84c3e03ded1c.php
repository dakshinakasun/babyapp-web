

<?php $__env->startSection('content'); ?>
<main class="sm:container sm:mx-auto sm:max-w-lg sm:mt-10">
    <div class="flex">
        <div class="w-full">
            <section class="flex flex-col break-words bg-white sm:border-1 sm:rounded-md sm:shadow-sm">

                <header class="font-semibold bg-gray-200 text-gray-700 py-5 px-6 sm:py-6 sm:px-8 sm:rounded-t-md">
                    <?php echo e(__('Delete Account')); ?>

                    
                </header>


                <form class="w-full px-6 space-y-6 sm:px-10 sm:space-y-8" method="POST" action="/profile/<?php echo e(Auth::user()->id); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>

                    <div class="flex flex-wrap">
                        <label for="password" class="block text-gray-700 text-sm font-bold mb-2 sm:mb-4">
                            <?php echo e(__('Verify your password')); ?>

                        </label>
                        
                        <input id="password" type="password"
                            class="form-input w-full <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                            required>

                        <?php if(session()->has('message')): ?>
                            <p class="text-red-500 text-xs italic mt-4">
                                <?php echo e(session()->get('message')); ?>

                            </p>
                        <?php endif; ?>
                    </div>

                    <div class="flex flex-wrap">
                        <button type="submit"
                        class="w-full select-none font-bold whitespace-no-wrap p-3 rounded-lg text-base leading-normal no-underline text-gray-100 bg-red-500 hover:bg-red-700 sm:py-4">
                            <?php echo e(__('Delete Account')); ?>

                        </button>

                        <p class="w-full text-xs text-center text-gray-700 my-6 sm:text-sm sm:my-8">
                            <?php echo e(__("You're breaking our hearts")); ?><br>
                        </p>
                        <a class="w-full text-xs text-center text-blue-500 hover:text-blue-700 sm:text-sm sm:mb-5" href="/">
                            <?php echo e(__('Go Back')); ?>

                        </a>
                    </div>
                </form>

            </section>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sites/14b/6/64ea45884e/public_html/bloomingmoms/backup/resources/views/profile/delete.blade.php ENDPATH**/ ?>